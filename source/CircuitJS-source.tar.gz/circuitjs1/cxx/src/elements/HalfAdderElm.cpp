/*
    Copyright (C) Paul Falstad and Iain Sharp

    This file is part of CircuitJS1.

    CircuitJS1 is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    CircuitJS1 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "HalfAdderElm.h"

#include "../core/StringTokenizer.h"

void HalfAdderElm::setupPins() {
    sizeX = 2;
    sizeY = 2;
    pins.assign(getPostCount(), Pin());
    pins[0] = Pin(this, 0, SIDE_E, "S");
    pins[0].output = true;
    pins[1] = Pin(this, 1, SIDE_E, "C");
    pins[1].output = true;
    pins[2] = Pin(this, 0, SIDE_W, "A");
    pins[3] = Pin(this, 1, SIDE_W, "B");
}

void HalfAdderElm::execute() {
    pins[0].value = pins[2].value != pins[3].value;
    pins[1].value = pins[2].value && pins[3].value;
}
